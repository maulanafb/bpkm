<div class="bcca-breadcrumb">
    <div class="bcca-breadcrumb-item">5<i class="fa fa-pencil"></i></div>
    <div class="bcca-breadcrumb-item bcca-breadcrumb-item-active active">4</div>
    <div class="bcca-breadcrumb-item">3</div>
    <div class="bcca-breadcrumb-item">2</div>
    <div class="bcca-breadcrumb-item">1</div>
    {{-- <div class="bcca-breadcrumb-item">Home</div> --}}
  </div>