  <!-- plugins:css -->
  <link rel="stylesheet" href={{ asset('vendors/feather/feather.css') }}>
  <link rel="stylesheet" href={{ asset('vendors/ti-icons/css/themify-icons.css') }}>
  <link rel="stylesheet" href={{ asset('vendors/css/vendor.bundle.base.css') }}>
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href={{ asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css') }}>
  <link rel="stylesheet" href={{ asset('vendors/ti-icons/css/themify-icons.css') }}>
  <link rel="stylesheet" type="text/css" href={{ asset('js/select.dataTables.min.css') }}>
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href={{ asset('css/vertical-layout-light/style.css') }}>
  <!-- endinject -->
  <link rel="shortcut icon" href={{ asset('/images/logo_munzalan_mini.png') }} />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
