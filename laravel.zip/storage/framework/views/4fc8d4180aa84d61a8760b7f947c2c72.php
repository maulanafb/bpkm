<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Kembali Ke Home</span>
            </a>
        </li>


    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\bpkm-main\resources\views/includes/sidebar-detail.blade.php ENDPATH**/ ?>