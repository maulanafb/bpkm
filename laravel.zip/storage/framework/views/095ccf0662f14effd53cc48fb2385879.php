<?php $__env->startSection('title'); ?>
    Ganti Password
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-style'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10">
    <style>
        /* CSS untuk efek glassmorphism pada card-header */
        .card-head {
            background-color: #ab509f;
            color: #fff;
            transition: background-color 0.3s ease, color 0.3s ease;
            /* Animasi selama 0.3 detik */
        }

        .card-head:hover {
            background-color: #fff;
            color: black;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container  mb-5" style="margin-top: 150px;margin-bottom: 100px">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="mx-auto px-5 py-2 rounded btn-primary card-head">
                        <?php echo e(__('Halaman Ubah Password')); ?>

                    </div>

                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger" role="alert">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('change-password')); ?>"
                            onsubmit="return confirmChangePassword();" id="change-password-form">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="current_password">Password Sekarang</label>
                                <input id="current_password" type="password" class="form-control" name="current_password"
                                    required autofocus>
                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="new_password">Password Baru</label>
                                <input id="new_password" type="password" class="form-control" name="new_password" required>
                            </div>

                            <div class="form-group">
                                <label for="new_password_confirmation">Konfirmasi Password Baru</label>
                                <input id="new_password_confirmation" type="password" class="form-control"
                                    name="new_password_confirmation" required>
                            </div>

                            <button type="button" class="btn btn-primary mx-auto" onclick="confirmChangePassword();">
                                <?php echo e(__('Ubah Password')); ?>

                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('addon-script'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script>
            function confirmChangePassword() {
                Swal.fire({
                    title: 'Konfirmasi',
                    text: 'Apakah Anda yakin ingin mengubah password?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Ya',
                    cancelButtonText: 'Batal',
                    customClass: {
                        confirmButton: 'custom-confirm-button-class',
                        icon: 'custom-icon-class'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Jika pengguna mengonfirmasi, kirim formulir atau lakukan tindakan lainnya
                        document.getElementById('change-password-form').submit();
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bpkm-main\resources\views/auth/passwords/change.blade.php ENDPATH**/ ?>