<!-- plugins:js -->
<script src=<?php echo e(asset('vendors/js/vendor.bundle.base.js')); ?>></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src=<?php echo e(asset('vendors/chart.js/Chart.min.js')); ?>></script>
<script src=<?php echo e(asset('vendors/datatables.net/jquery.dataTables.js')); ?>></script>
<script src=<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>></script>
<script src=<?php echo e(asset('js/dataTables.select.min.js')); ?>></script>

<!-- End plugin js for this page -->
<!-- inject:js -->
<script src=<?php echo e(asset('js/off-canvas.js')); ?>></script>
<script src=<?php echo e(asset('js/hoverable-collapse.js')); ?>></script>
<script src=<?php echo e(asset('js/template.js')); ?>></script>
<script src=<?php echo e(asset('js/settings.js')); ?>></script>
<script src=<?php echo e(asset('js/todolist.js')); ?>></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src=<?php echo e(asset('js/dashboard.js')); ?>></script>
<script src=<?php echo e(asset('js/Chart.roundedBarCharts.js')); ?>></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>

<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/i18n/defaults-*.min.js"></script>
<?php /**PATH C:\xampp\htdocs\bpkm-main\resources\views/includes/script.blade.php ENDPATH**/ ?>